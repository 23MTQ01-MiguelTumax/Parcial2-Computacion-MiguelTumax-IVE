/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcial2.migueltumax.ive;

/**
 *
 * @author tumax
 */
public class Parcial2MiguelTumaxIVE {

    public static void main(String[] args) {
        FormularioPrincipal window = new FormularioPrincipal();
        window.setVisible(true);
    }
}
